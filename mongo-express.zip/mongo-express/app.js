const express = require("express");
const app = express();
const mongoose = require('mongoose');
const { engine } = require("express-handlebars");
const path = require("path");
const fs = require("fs");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// 配置 Handlebars
app.engine("handlebars", engine({
    runtimeOptions: {
        allowProtoPropertiesByDefault: true, // 允許訪問原型鏈屬性
        allowProtoMethodsByDefault: true,   // 允許訪問原型鏈方法
    }
}));
app.set("view engine", "handlebars");

app.use("/frank", express.static("public"));

mongoose.connect('mongodb://localhost:27017/school')
    .then(() => console.log("MongoDB 連線成功"))
    .catch(err => console.error("MongoDB 連線失敗：", err))

// 定義 Schema
const SchoolSchema = new mongoose.Schema({
    name: String,
    level: Number,
    is_close: Boolean,
    created_at: {
        type: Date,
        default: Date.now
    }
})

// 使用 mongoose.model，而不是 mongo.model
const School = mongoose.model('School', SchoolSchema)    


//取得所有資料
app.get('/', async (req, res) => {
    try {
        const schools = await School.find({})
        res.render("home", { schools: schools });
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

//取得篩選資料
app.get('/search', async (req, res) => {
    const { name, level, is_close } = req.query;

    const filter = []; // 用於存儲篩選條件
    const query = {}; // 用於構建 MongoDB 查詢

    // 動態構建查詢條件
    if (name) {
        query.name = { $regex: name, $options: 'i' }; // 模糊查詢，忽略大小寫
        filter.push(`校名: ${name}`); // 將篩選條件加入 filter 陣列
    }
    if (level) {
        query.level = level; // 精確查詢 level
        filter.push(`等級: ${level}`); // 將篩選條件加入 filter 陣列
    }
    if (is_close !== undefined && is_close !== null && is_close !== "") {
        query.is_close = is_close === "true"; // 將 is_close 轉為布爾值
        filter.push(`是否閉校: ${is_close === "true" ? "是" : "否"}`); // 將篩選條件加入 filter 陣列
    }

    try {
        const schools = await School.find(query);
        res.render("home", { schools: schools, filter: filter.join(", ") }); // 將 filter 陣列轉為字串傳遞
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

//新增資料
app.post('/add', async (req, res) => {
    const { name, level, is_close } = req.body;
    try {
        const newSchool = await School.create({
            name: name,
            level: level,
            is_close: is_close
        });
        res.redirect('/');
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

//編輯資料
app.put('/school', async (req, res) => {
    const { id, name, level, is_close } = req.query;

    try {
        // 動態構建更新對象
        const updateData = {};
        if (name !== undefined) updateData.name = name;
        if (level !== undefined) updateData.level = level;
        if (is_close !== undefined) updateData.is_close = is_close === "true"; // 將字符串轉為布爾值

        // 檢查是否有需要更新的資料
        if (Object.keys(updateData).length > 0) {
            await School.updateOne({ _id: id }, updateData)
                .then(r => {
                    res.status(200).send(r);
                });
        } else {
            res.status(400).send({ error: "未提供任何修改資料" });
        }
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

//刪除資料
app.delete('/school', async(req, res) => {
    const {id} = req.query
    try {
        await School.deleteOne({
            _id: id
        }).then(r => {
            res.status(200).send(r)
        })
    } catch (err) {
        res.status(500).send({ error: err.message })
    }
    
})


app.listen(2000, () => {
    console.log('running on port 2000');
})