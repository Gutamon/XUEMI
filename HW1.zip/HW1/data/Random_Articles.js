const {faker} = require('@faker-js/faker');
const topics = [];

for (let i = 0; i < 10; i++) {
    topics.push({
        title: faker.lorem.sentence(),
        subTitle: faker.lorem.sentences(),
        date: faker.date.past().toString(),
        content: faker.lorem.paragraphs(),
        publish: [true, false][
            Math.floor(Math.random() * [true, false].length)
        ],
        url: `/articles/${i}`
    });
}
module.exports = topics;