const express = require("express");
const app = express();
const { engine } = require("express-handlebars");  // 注意這裡的解構賦值
const topics = require("./data/Random_Articles.js");

app.engine("handlebars", engine());   // 使用 engine() 而不是 exphbs()
app.set("view engine", "handlebars");

app.listen(3000, () => {
    console.log('running on port 3000');
})

app.use("/frank", express.static("public"));

app.get("/", (req, res) => {
    res.render("home");
});

app.get("/articles", (req, res) => {
    res.render("article", { articles: topics });
});

app.get("/articles/:id", (req, res) => {
    const id = req.params.id;
    res.render("topic",{
        topic: [topics[id]],
        backUrl: "/articles"
    });
});